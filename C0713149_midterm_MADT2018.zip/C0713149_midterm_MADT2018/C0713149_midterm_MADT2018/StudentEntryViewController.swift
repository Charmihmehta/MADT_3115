//
//  StudentEntryViewController.swift
//  C0713149_midterm_MADT2018
//
//  Created by MacStudent on 2018-02-28.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class StudentEntryViewController: UIViewController ,UIPickerViewDataSource , UIPickerViewDelegate{
    
    

    
    @IBOutlet weak var txtID: UITextField!
    
    @IBOutlet weak var txtName: UITextField!
    
    
    @IBOutlet weak var segGender: UISegmentedControl!
    
    @IBOutlet weak var lblCourse: UILabel!
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtDOB: UITextField!
    
    @IBOutlet weak var txtMaths: UITextField!
    
    @IBOutlet weak var txtSci: UITextField!
    
    @IBOutlet weak var txtEng: UITextField!
    
    @IBOutlet weak var txtHindi: UITextField!
    
    @IBOutlet weak var txtSst: UITextField!
    
    @IBOutlet weak var pickerCourse: UIPickerView!
    
    @IBOutlet weak var lblPer: UILabel!
    
    @IBOutlet weak var lblMrks: UILabel!
    
    
    @IBOutlet weak var lblGrade: UILabel!
    var course : [String] = [String]()
    var std = Student()
   

    override func viewDidLoad() {
        super.viewDidLoad()
        course = ["MADT" ,"MAVT" , "OHST" ,"PPM" ,"CMT"]
        pickerCourse.dataSource = self
        pickerCourse.delegate = self
    
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return course.count
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        lblCourse.text = course[row]
        
        print(course[ pickerCourse.selectedRow(inComponent: 0)])
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return course[row]
    }
    
    
    @IBAction func segGenderAction(_ sender: UISegmentedControl) {
        
       if sender.selectedSegmentIndex == 0
        {
            std.stdCourse = "Male"
        }
        else if sender.selectedSegmentIndex == 1
       {
            std.stdCourse = "Female"
        }
    }
    
//    func totalMrks()
//    {
//        let a = txtMaths.text!
//        let b = txtHindi.text!
//        let c = txtEng.text!
//        let d = txtSci.text!
//        let e = txtSst.text!
//       // let total = Int (txtMaths.text! + txtHindi.text! + txtEng.text! + txtSci.text! + txtSst.text!)
//        print(a)
//        let sum = Int(a + b + c + d + e)
//        print(sum)
//        lblMrks.text! = "\(sum)"
//    }
//
    func totalPer()
    {
        var sum = 0
        for i in std.stdSub
        {
            sum = sum + Int(i)!
        }
        let per = sum / 5
        
        print(sum)
        
        if(per >= 95)
        {
            lblGrade.text! = "A+"
        }
        else if (per >= 85 && per < 95)
        {
            lblGrade.text! = "A"
        }
        else if (per >= 75 && per < 85)
        {
             lblGrade.text! = "B+"
        }
        else if (per >= 65 && per < 75 )
        {
             lblGrade.text! = "B"
        }
        else if (per >= 55 && per < 65)
        {
             lblGrade.text! = "C+"
        }
        else if (per >= 50 && per < 55)
        {
             lblGrade.text! = "C"
        }
        else if (per >= 45 && per < 50)
        {
             lblGrade.text! = "D+"
        }
        else if(per < 45)
        {
             lblGrade.text! = "FAIL"
        }
    }
    
    @IBAction func btnSave(_ sender: UIButton) {
       
        
        std.stdID = txtID.text!
        std.stdName = txtName.text!
        
        std.stdCourse = lblCourse.text!
        std.stdEmail = txtEmail.text!
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-mm-yyyy"
        dateFormatter.timeZone = TimeZone(abbreviation: "GMT+0:00")
        std.stdDOB = dateFormatter.date(from: txtDOB.text!)
        std.stdSub = [txtMaths.text! , txtSci.text! , txtEng.text! , txtHindi.text! , txtSst.text!]
        print(std.stdSub)
        var sum = 0
        for i in std.stdSub
        {
            sum = sum + Int(i)!
        }
       let per = sum / 5
        
        print(sum)
        lblPer.text = "\(sum)"
        print(per)
        lblMrks.text = "\(per)"
        std.stdMrks = lblMrks.text!
        std.stdPer = lblPer.text!
        totalPer()
       std.stdGrade = lblGrade.text!
       
        let flag = Student.addStudent(std: std)
        if flag == true
        {
            print("saved")
        }
        else
        {
            print("not saved")
        }
    }
    
    @IBAction func btnLogOut(_ sender: UIButton) {
        
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let loginVC = storyBoard.instantiateViewController(withIdentifier: "loginVC")
        self.present(loginVC , animated: true , completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
