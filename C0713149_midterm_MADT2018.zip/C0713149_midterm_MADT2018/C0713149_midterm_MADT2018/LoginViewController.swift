//
//  ViewController.swift
//  C0713149_midterm_MADT2018
//
//  Created by MacStudent on 2018-02-28.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    
    @IBOutlet weak var txtUserName: UITextField!
    
    var myUserDefault : UserDefaults!
    @IBOutlet weak var mySwitch: UISwitch!
    @IBOutlet weak var txtPsw: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        myUserDefault  = UserDefaults.standard
        if let userName = myUserDefault.value(forKey: "userName"){
            txtUserName.text = userName as? String
        }
        
        if let userPassword = myUserDefault.value(forKey: "userPassword"){
            txtPsw.text = userPassword as? String
        }
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func btnLogin(_ sender: UIButton) {
        
        if(txtUserName.text! == "admin" && txtPsw.text! == "123")
        {
            if self.mySwitch.isOn{
                self.myUserDefault.set(txtUserName.text, forKey: "userName")
                self.myUserDefault.set(txtPsw.text, forKey: "userPassword")
            }else{
                self.myUserDefault.removeObject(forKey: "userName")
                self.myUserDefault.removeObject(forKey: "userPassword")
            }
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let loginVC = storyBoard.instantiateViewController(withIdentifier: "entryVC")
            self.present(loginVC , animated: true , completion: nil)
        }
        
        else{
            let alert = UIAlertController(title: "Error", message: "Invalid UserId/Password", preferredStyle: UIAlertControllerStyle.alert)
            let actionOk = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil)
            alert.addAction(actionOk)
            self.present(alert , animated: true , completion: nil)
        }
    }
}

