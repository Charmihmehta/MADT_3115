//
//  Student.swift
//  C0713149_midterm_MADT2018
//
//  Created by MacStudent on 2018-02-28.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Student
{
    var stdID : String!
    var stdName : String!
    var stdGender : String!
    var stdCourse : String!
    var stdEmail : String!
    var stdDOB : Date!
    var stdSub : [String]!
    var stdMrks : String!
    var stdPer : String!
    var stdGrade : String!
    private static var stdList = [String: Student]()
    
    init()
    {
        self.stdID = "-1"
        self.stdName = "no"
        self.stdGender = "no"
        self.stdCourse = "no"
        self.stdEmail = "no"
        self.stdDOB = Date()
        self.stdSub = []
    }
    
    init(_ stdID : String, _ stdName : String,_ stdGender : String,_ stdCourse : String ,_ stdEmail : String ,_ stdDOB : Date, _ stdSub : [String])
    {
        self.stdID = stdID
        self.stdName = stdName
        self.stdGender = stdGender
        self.stdCourse = stdCourse
        self.stdEmail = stdEmail
        self.stdDOB = stdDOB
        self.stdSub = []
    }
    
    static func addStudent(std: Student) -> Bool
    {
        if self.stdList[std.stdID] == nil
        {
            self.stdList[std.stdID] = std
            return true
        }
        return false
    }
    
    static func getStudent() -> [String: Student]
    {
        return stdList
    }
}
